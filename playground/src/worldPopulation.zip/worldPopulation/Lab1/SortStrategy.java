package worldPopulation.Lab1;

public interface SortStrategy {
	public long[] sort(long[] data);
	public String getName();
	public long getTime();
}
