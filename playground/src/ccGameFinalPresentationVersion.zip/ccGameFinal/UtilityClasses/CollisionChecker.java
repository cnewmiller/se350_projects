package ccGameFinal.UtilityClasses;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import ccGameFinal.Interfaces.Collidable;

public class CollisionChecker implements Observer {
	private static CollisionChecker instance;
	
	private ArrayList<Collidable> objects;
	
	private CollisionChecker() {
		objects = new ArrayList<>();
//		toRemove = new LinkedList<>();
	}
	
	public static CollisionChecker getInstance() {
		return (instance == null ? instance = new CollisionChecker() : instance);
	}
	public void addChild(Collidable c) {
		objects.add(c);
	}
	public void removeChild(Collidable c) {
		objects.remove(c);
//		toRemove.add(c);
	}

	public void reset() {
		objects.clear();
//		toRemove.clear();
	}
	//private Queue<Collidable> toRemove = null;
	
	@Override
	public void update(Observable o, Object arg) {

		if (o instanceof Collidable) {
			
			Collidable c = (Collidable) o;
			Point p = c.getPoint();
			for(Collidable other: objects) {
				if (other != c && p.equals(other.getPoint())) {
					c.collideWith(other);
					other.collideWith(c);
				}
			}
		}

	}
	
}
