package ccGameFinal.Interfaces;

public interface CollisionFunction {
	public void doCollision(Collidable self, Collidable other);
}
