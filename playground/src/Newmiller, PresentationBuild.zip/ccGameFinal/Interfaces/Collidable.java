package ccGameFinal.Interfaces;

import ccGameFinal.UtilityClasses.Point;

public interface Collidable {
	public Point getPoint();
	public void collideWith(Collidable c);
	public void addCollisionClass(Class<?> otherClass, CollisionFunction f);
	public void removeCollisionClass(Class<?> otherClass);
	
}
