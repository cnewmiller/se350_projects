package ccGameFinal.UtilityClasses;

import ccGameFinal.OceanMap;
import ccGameFinal.Interfaces.GridChecker;

/**
 * The simple common functionality of ship movement.
 * Checks points in contact with the given Point against the given grid. No special checks or conditions.
 * 
 * @author Clay
 *
 */
public class IslandFinderChecker implements GridChecker {

	@Override
	public boolean checkLeft(Point p, boolean[][] grid) {
		int xPos = p.getX(), yPos = p.getY();
		if (xPos > 1) {
			
			if (grid[xPos-1][yPos] == OceanMap.TAKENSQUARE) {
				return true;
			}
		}
		return false;
	}
	@Override
	public  boolean checkRight(Point p, boolean[][] grid) {
		int xPos = p.getX(), yPos = p.getY();
		if (xPos < grid.length-2) {
			if (grid[xPos+1][yPos] == OceanMap.TAKENSQUARE) {
				return true;
			}
		}
		return false;
	}
	@Override
	public  boolean checkUp(Point p, boolean[][] grid) {
		int xPos = p.getX(), yPos = p.getY();
		if (yPos > 1) {
			if (grid[xPos][yPos-1] == OceanMap.TAKENSQUARE ) {
				return true;
			}
		}
		return false;
	}
	@Override
	public  boolean checkDown(Point p, boolean[][] grid) {
		int xPos = p.getX(), yPos = p.getY();
		if (yPos < grid[0].length-2) {
			
			if (grid[xPos][yPos+1] == OceanMap.TAKENSQUARE ) {
				return true;
			}

		}
		return false;
	}

}
