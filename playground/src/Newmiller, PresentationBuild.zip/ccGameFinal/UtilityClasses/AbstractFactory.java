package ccGameFinal.UtilityClasses;

import ccGameFinal.PirateShip;

public abstract class AbstractFactory {
	public PirateShip getPirate() {
		return createShip();
	}
	
	protected abstract PirateShip createShip();
}
